import { motion } from "framer-motion";
import { Star } from "lucide-react";

const testimonials = [
  {
    name: "xX_Voidslayer_Xx",
    tag: "@voidslayer",
    server: "Hypixel",
    quote: "My KD ratio tripled the first week. This client is absolutely insane. PvP feels like cheating without actually cheating.",
    stars: 5,
    accent: "#ff1a1a",
    initials: "VS",
  },
  {
    name: "PurpleReaper99",
    tag: "@purplereaper",
    server: "PvP Legacy",
    quote: "350 FPS consistently. My old potato PC was running at 40. This is black magic. The FPS boost alone is worth it.",
    stars: 5,
    accent: "#a855f7",
    initials: "PR",
  },
  {
    name: "CrimsonBl4de",
    tag: "@crimsonblade",
    server: "Badlion",
    quote: "The module system is god-tier. Fully customizable HUD, clean GUI, no bloat. This is the client I've been waiting for.",
    stars: 5,
    accent: "#ff4466",
    initials: "CB",
  },
  {
    name: "ShadowPing_0ms",
    tag: "@shadowping",
    server: "Minemen Club",
    quote: "Built-in cosmetics are fire. The cape animations are smoother than anything I've seen. Opponents think I'm a dev.",
    stars: 5,
    accent: "#7c3aed",
    initials: "SP",
  },
  {
    name: "ZeroPing_God",
    tag: "@zeropinggod",
    server: "VeltPvP",
    quote: "Hit registration is on another level. Zero delay, perfectly tuned knockback. Every combo lands exactly how it should.",
    stars: 5,
    accent: "#ff1a1a",
    initials: "ZP",
  },
  {
    name: "NightShade_KC",
    tag: "@nightshadekc",
    server: "CubeCraft",
    quote: "The smooth animations ported from 1.7 are absolutely perfect. Movement feels completely different. Way better than anything else.",
    stars: 5,
    accent: "#c026d3",
    initials: "NS",
  },
];

export function Testimonials() {
  return (
    <section id="testimonials" className="py-24 bg-background relative overflow-hidden">
      <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,_hsl(270_100%_50%_/_0.03)_0%,_transparent_70%)]" />

      <div className="container mx-auto px-4 relative z-10">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center mb-16"
        >
          <p className="text-primary font-heading font-bold tracking-widest uppercase text-sm mb-3">Community</p>
          <h2 className="text-4xl md:text-5xl font-heading font-bold uppercase text-white mb-4">
            Trusted by <span className="text-primary">Killers</span>
          </h2>
          <p className="text-muted-foreground text-lg max-w-2xl mx-auto">
            50,000+ players have already made the switch. Here's what they say.
          </p>
        </motion.div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {testimonials.map((t, i) => (
            <motion.div
              key={i}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: i * 0.1 }}
              className="relative group"
              data-testid={`testimonial-card-${i}`}
            >
              <div
                className="relative rounded-xl p-6 bg-white/[0.03] backdrop-blur-md border border-white/10 group-hover:border-opacity-60 transition-all duration-300 h-full"
                style={{
                  borderColor: `${t.accent}22`,
                  boxShadow: `0 0 0 1px ${t.accent}11`,
                }}
              >
                <div
                  className="absolute inset-0 rounded-xl opacity-0 group-hover:opacity-100 transition-opacity duration-500 pointer-events-none"
                  style={{
                    boxShadow: `inset 0 0 30px ${t.accent}08, 0 0 30px ${t.accent}15`,
                  }}
                />

                <div className="flex items-start gap-4 mb-4">
                  <div
                    className="w-12 h-12 rounded-full flex items-center justify-center font-heading font-bold text-white text-lg flex-shrink-0"
                    style={{
                      background: `linear-gradient(135deg, ${t.accent}44, ${t.accent}22)`,
                      border: `2px solid ${t.accent}55`,
                      boxShadow: `0 0 12px ${t.accent}33`,
                    }}
                  >
                    {t.initials}
                  </div>
                  <div className="min-w-0">
                    <div className="font-heading font-bold text-white uppercase tracking-wide text-sm truncate">
                      {t.name}
                    </div>
                    <div className="text-xs text-muted-foreground">{t.tag}</div>
                    <div
                      className="text-xs font-bold mt-0.5"
                      style={{ color: t.accent }}
                    >
                      {t.server}
                    </div>
                  </div>
                </div>

                <div className="flex gap-0.5 mb-4">
                  {[...Array(t.stars)].map((_, si) => (
                    <Star
                      key={si}
                      className="w-4 h-4 fill-current"
                      style={{ color: t.accent }}
                    />
                  ))}
                </div>

                <p className="text-muted-foreground text-sm leading-relaxed">
                  "{t.quote}"
                </p>

                <div
                  className="absolute bottom-0 left-0 right-0 h-px rounded-b-xl"
                  style={{
                    background: `linear-gradient(90deg, transparent, ${t.accent}44, transparent)`,
                  }}
                />
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
