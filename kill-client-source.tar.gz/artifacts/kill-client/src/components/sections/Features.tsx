import { motion } from "framer-motion";
import { Zap, Crosshair, LayoutDashboard, Palette, Eye, Activity, Cpu, Blocks } from "lucide-react";

const features = [
  { icon: Zap, title: "FPS Boost", desc: "Proprietary rendering engine optimizations pushing frame rates beyond limits." },
  { icon: Crosshair, title: "PvP Optimization", desc: "Zero hit-delay, custom crosshairs, and precisely tuned knockback algorithms." },
  { icon: LayoutDashboard, title: "Clean GUI", desc: "Modern, distraction-free interface built for speed and accessibility." },
  { icon: Palette, title: "Built-in Cosmetics", desc: "Exclusive capes, wings, and halos to flex on your opponents." },
  { icon: Eye, title: "Advanced HUD", desc: "Fully customizable heads-up display tracking every vital stat in real-time." },
  { icon: Activity, title: "Smooth Animations", desc: "Fluid 1.7-style combat animations ported seamlessly to modern versions." },
  { icon: Cpu, title: "Lightweight", desc: "Minimal memory footprint ensuring peak performance on any hardware." },
  { icon: Blocks, title: "Custom Modules", desc: "Expand your dominance with our powerful scripting API and mod ecosystem." },
];

export function Features() {
  return (
    <section id="features" className="py-24 bg-background relative border-t border-border/50">
      <div className="container mx-auto px-4">
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center mb-16"
        >
          <h2 className="text-4xl md:text-5xl font-heading font-bold uppercase text-white mb-4">
            Unfair <span className="text-primary">Advantage</span>
          </h2>
          <p className="text-muted-foreground text-lg max-w-2xl mx-auto">
            Everything you need to crush your enemies. Nothing you don't.
          </p>
        </motion.div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {features.map((feature, i) => (
            <motion.div
              key={i}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: i * 0.1 }}
              className="glass-card p-6 rounded-xl group hover:-translate-y-2 hover:border-primary/50 transition-all duration-300 relative overflow-hidden"
            >
              <div className="absolute inset-0 bg-gradient-to-br from-primary/10 to-transparent opacity-0 group-hover:opacity-100 transition-opacity" />
              <feature.icon className="w-10 h-10 text-primary mb-4" />
              <h3 className="text-xl font-bold text-white mb-2 font-heading uppercase">{feature.title}</h3>
              <p className="text-muted-foreground text-sm leading-relaxed">{feature.desc}</p>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
