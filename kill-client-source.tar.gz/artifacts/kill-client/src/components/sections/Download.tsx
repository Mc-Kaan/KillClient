import { motion } from "framer-motion";
import { Download as DownloadIcon, MessageCircle, Shield, Cpu, Zap } from "lucide-react";

const versions = ["1.8.9", "1.12.2", "1.16.5", "1.18.2", "1.19.4", "1.20.4", "1.21"];

const highlights = [
  { icon: Shield, label: "100% Safe", desc: "Undetected on all major servers" },
  { icon: Cpu, label: "Optimized", desc: "Every CPU architecture supported" },
  { icon: Zap, label: "Instant Start", desc: "Boot-to-game in under 30 seconds" },
];

export function Download() {
  return (
    <section id="download" className="py-32 bg-background relative overflow-hidden">
      <div className="absolute inset-0">
        <div
          className="absolute inset-0"
          style={{
            background: `
              radial-gradient(ellipse 80% 50% at 50% 0%, hsl(0 100% 55% / 0.06) 0%, transparent 60%),
              radial-gradient(ellipse 60% 40% at 50% 100%, hsl(270 100% 50% / 0.04) 0%, transparent 60%)
            `,
          }}
        />
        <div
          className="absolute inset-0 opacity-[0.015]"
          style={{
            backgroundImage: `repeating-linear-gradient(
              0deg, transparent, transparent 63px,
              rgba(255,255,255,0.3) 63px, rgba(255,255,255,0.3) 64px
            )`,
          }}
        />
      </div>

      <div className="container mx-auto px-4 relative z-10">
        <div className="max-w-4xl mx-auto">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-center mb-12"
          >
            <div
              className="inline-block px-4 py-1.5 rounded-full text-xs font-heading font-bold tracking-widest uppercase mb-6"
              style={{
                background: "hsl(0 100% 55% / 0.1)",
                border: "1px solid hsl(0 100% 55% / 0.3)",
                color: "hsl(0 100% 65%)",
              }}
            >
              Free Forever
            </div>

            <h2 className="text-5xl md:text-7xl font-heading font-bold uppercase text-white mb-4 leading-tight">
              Ready to <span className="text-primary text-shadow-glow">Dominate?</span>
            </h2>

            <p className="text-xl text-muted-foreground mb-4 max-w-2xl mx-auto">
              Join 50,000+ players who've already upgraded their game. No cost. No limits. Just kills.
            </p>

            <div
              className="inline-flex items-center gap-2 px-3 py-1.5 rounded-md text-sm font-mono mb-10"
              style={{
                background: "hsl(0 0% 8%)",
                border: "1px solid hsl(0 0% 18%)",
                color: "hsl(0 0% 60%)",
              }}
            >
              <span
                className="w-2 h-2 rounded-full"
                style={{ background: "#22ff66", boxShadow: "0 0 6px #22ff66" }}
              />
              v2.4.1 — For Minecraft 1.8 — 1.21
            </div>

            <div className="flex flex-col sm:flex-row items-center justify-center gap-4 mb-12">
              <motion.a
                href="#"
                whileHover={{ scale: 1.04 }}
                whileTap={{ scale: 0.97 }}
                className="group relative flex items-center gap-3 px-10 py-4 font-heading font-bold text-lg uppercase tracking-widest text-white rounded-lg overflow-hidden"
                style={{
                  background: "linear-gradient(135deg, hsl(0 100% 40%), hsl(0 100% 55%))",
                  boxShadow: "0 0 30px hsl(0 100% 55% / 0.3), 0 0 60px hsl(0 100% 55% / 0.1)",
                }}
                data-testid="button-download-free"
              >
                <div className="absolute inset-0 bg-white/0 group-hover:bg-white/10 transition-colors duration-300" />
                <DownloadIcon className="w-5 h-5 relative z-10" />
                <span className="relative z-10">Download Free</span>
              </motion.a>

              <motion.a
                href="#"
                whileHover={{ scale: 1.04 }}
                whileTap={{ scale: 0.97 }}
                className="group flex items-center gap-3 px-10 py-4 font-heading font-bold text-lg uppercase tracking-widest text-white rounded-lg border transition-all duration-300"
                style={{
                  borderColor: "hsl(270 100% 50% / 0.4)",
                  background: "hsl(270 100% 50% / 0.05)",
                }}
                data-testid="button-join-discord"
              >
                <MessageCircle className="w-5 h-5" />
                Join Discord
              </motion.a>
            </div>

            <div className="flex flex-wrap justify-center gap-2 mb-16">
              <span className="text-muted-foreground text-sm mr-2 self-center font-heading uppercase tracking-wider text-xs">Versions:</span>
              {versions.map((v) => (
                <span
                  key={v}
                  className="px-3 py-1 rounded-md text-xs font-mono"
                  style={{
                    background: "hsl(0 0% 10%)",
                    border: "1px solid hsl(0 0% 18%)",
                    color: "hsl(0 0% 70%)",
                  }}
                >
                  {v}
                </span>
              ))}
            </div>
          </motion.div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {highlights.map((h, i) => (
              <motion.div
                key={i}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.15 }}
                className="flex items-start gap-4 p-5 rounded-xl"
                style={{
                  background: "hsl(0 0% 8%)",
                  border: "1px solid hsl(0 0% 15%)",
                }}
                data-testid={`download-highlight-${i}`}
              >
                <div
                  className="p-2.5 rounded-lg flex-shrink-0"
                  style={{
                    background: "hsl(0 100% 55% / 0.1)",
                    border: "1px solid hsl(0 100% 55% / 0.2)",
                  }}
                >
                  <h.icon className="w-5 h-5 text-primary" />
                </div>
                <div>
                  <div className="font-heading font-bold text-white uppercase tracking-wide text-sm mb-1">
                    {h.label}
                  </div>
                  <div className="text-muted-foreground text-xs">{h.desc}</div>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
