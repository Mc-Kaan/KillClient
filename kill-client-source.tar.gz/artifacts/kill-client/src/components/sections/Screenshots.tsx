import { motion, useMotionValue, useTransform } from "framer-motion";
import { useRef } from "react";

const screenshots = [
  {
    title: "PvP Combat",
    desc: "Zero-latency combat with custom hit registration",
    gradient: "from-red-900/80 via-red-950/60 to-black",
    accent: "#ff1a1a",
    detail: "135ms CPS",
  },
  {
    title: "Custom HUD",
    desc: "Fully modular heads-up display",
    gradient: "from-purple-900/80 via-purple-950/60 to-black",
    accent: "#a855f7",
    detail: "350 FPS",
  },
  {
    title: "Cosmetics",
    desc: "Exclusive visual enhancements & capes",
    gradient: "from-rose-900/80 via-red-950/60 to-black",
    accent: "#ff4466",
    detail: "120+ Capes",
  },
  {
    title: "Module Menu",
    desc: "Sleek toggleable module interface",
    gradient: "from-violet-900/80 via-purple-950/60 to-black",
    accent: "#7c3aed",
    detail: "80+ Modules",
  },
  {
    title: "FPS Graph",
    desc: "Real-time performance analytics",
    gradient: "from-red-950/80 via-black to-purple-950/60",
    accent: "#ff2244",
    detail: "Live Metrics",
  },
  {
    title: "World Renderer",
    desc: "Enhanced rendering pipeline",
    gradient: "from-fuchsia-900/80 via-purple-950/60 to-black",
    accent: "#c026d3",
    detail: "Shader Pack",
  },
];

function TiltCard({ item, index }: { item: typeof screenshots[0]; index: number }) {
  const ref = useRef<HTMLDivElement>(null);
  const x = useMotionValue(0);
  const y = useMotionValue(0);
  const rotateX = useTransform(y, [-0.5, 0.5], [8, -8]);
  const rotateY = useTransform(x, [-0.5, 0.5], [-8, 8]);

  const handleMouseMove = (e: React.MouseEvent<HTMLDivElement>) => {
    if (!ref.current) return;
    const rect = ref.current.getBoundingClientRect();
    const normalX = (e.clientX - rect.left) / rect.width - 0.5;
    const normalY = (e.clientY - rect.top) / rect.height - 0.5;
    x.set(normalX);
    y.set(normalY);
  };

  const handleMouseLeave = () => {
    x.set(0);
    y.set(0);
  };

  return (
    <motion.div
      ref={ref}
      initial={{ opacity: 0, y: 40 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true }}
      transition={{ delay: index * 0.1, duration: 0.6 }}
      style={{ rotateX, rotateY, transformStyle: "preserve-3d", perspective: 800 }}
      onMouseMove={handleMouseMove}
      onMouseLeave={handleMouseLeave}
      className="relative group cursor-pointer"
      data-testid={`screenshot-card-${index}`}
    >
      <div
        className="relative rounded-xl overflow-hidden border border-white/10 group-hover:border-primary/50 transition-all duration-300"
        style={{
          boxShadow: `0 0 0 1px ${item.accent}22, 0 20px 60px ${item.accent}22`,
        }}
      >
        <div
          className={`h-52 bg-gradient-to-br ${item.gradient} relative overflow-hidden`}
        >
          <div
            className="absolute inset-0 opacity-20"
            style={{
              backgroundImage: `
                repeating-linear-gradient(0deg, transparent, transparent 31px, ${item.accent}22 31px, ${item.accent}22 32px),
                repeating-linear-gradient(90deg, transparent, transparent 31px, ${item.accent}22 31px, ${item.accent}22 32px)
              `,
            }}
          />
          <div
            className="absolute top-3 right-3 px-2 py-1 rounded text-xs font-bold font-heading tracking-wider"
            style={{
              background: `${item.accent}22`,
              border: `1px solid ${item.accent}55`,
              color: item.accent,
              backdropFilter: "blur(8px)",
            }}
          >
            {item.detail}
          </div>
          <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent" />
          <div
            className="absolute inset-0 opacity-0 group-hover:opacity-100 transition-opacity duration-500"
            style={{
              background: `radial-gradient(circle at 50% 50%, ${item.accent}15, transparent 70%)`,
            }}
          />
          <div className="absolute bottom-4 left-4 right-4">
            <div className="flex gap-1 mb-2">
              {[...Array(3)].map((_, i) => (
                <div
                  key={i}
                  className="h-1 rounded-full flex-1"
                  style={{ background: i === 0 ? item.accent : `${item.accent}33` }}
                />
              ))}
            </div>
          </div>
        </div>
        <div className="p-4 bg-white/[0.03] backdrop-blur-md">
          <h3 className="font-heading font-bold text-white text-lg uppercase tracking-wide mb-1">
            {item.title}
          </h3>
          <p className="text-muted-foreground text-sm">{item.desc}</p>
        </div>
        <div
          className="absolute inset-0 rounded-xl opacity-0 group-hover:opacity-100 transition-opacity duration-300 pointer-events-none"
          style={{
            background: `linear-gradient(135deg, ${item.accent}08 0%, transparent 60%)`,
          }}
        />
      </div>
    </motion.div>
  );
}

export function Screenshots() {
  return (
    <section id="screenshots" className="py-24 bg-background relative overflow-hidden">
      <div className="absolute top-0 left-1/4 w-96 h-96 rounded-full opacity-5 blur-3xl"
        style={{ background: "radial-gradient(circle, #ff1a1a, transparent)" }} />
      <div className="absolute bottom-0 right-1/4 w-96 h-96 rounded-full opacity-5 blur-3xl"
        style={{ background: "radial-gradient(circle, #a855f7, transparent)" }} />

      <div className="container mx-auto px-4 relative z-10">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center mb-16"
        >
          <p className="text-primary font-heading font-bold tracking-widest uppercase text-sm mb-3">In Action</p>
          <h2 className="text-4xl md:text-5xl font-heading font-bold uppercase text-white mb-4">
            See the <span className="text-primary">Power</span>
          </h2>
          <p className="text-muted-foreground text-lg max-w-2xl mx-auto">
            Every pixel. Every frame. Engineered for dominance.
          </p>
        </motion.div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {screenshots.map((item, i) => (
            <TiltCard key={i} item={item} index={i} />
          ))}
        </div>
      </div>
    </section>
  );
}
