import { motion } from "framer-motion";

export function Navigation() {
  return (
    <motion.nav 
      initial={{ y: -100 }}
      animate={{ y: 0 }}
      className="fixed top-0 left-0 right-0 z-50 bg-background/80 backdrop-blur-md border-b border-border/50"
    >
      <div className="container mx-auto px-4 h-16 flex items-center justify-between">
        <div className="flex items-center gap-2">
          <svg width="32" height="32" viewBox="0 0 32 32" fill="none" xmlns="http://www.w3.org/2000/svg" className="text-primary drop-shadow-[0_0_8px_rgba(255,0,0,0.5)]">
            <path d="M6 4H12V12L20 4H28L18 16L28 28H20L12 18V28H6V4Z" fill="currentColor"/>
          </svg>
          <span className="font-heading font-bold text-2xl tracking-wider text-white">KILL<span className="text-primary">CLIENT</span></span>
        </div>
        
        <div className="hidden md:flex items-center gap-6 text-sm font-medium text-muted-foreground">
          <a href="#features" className="hover:text-primary transition-colors">Features</a>
          <a href="#screenshots" className="hover:text-primary transition-colors">Screenshots</a>
          <a href="#stats" className="hover:text-primary transition-colors">Stats</a>
          <a href="#testimonials" className="hover:text-primary transition-colors">Testimonials</a>
          <a href="#faq" className="hover:text-primary transition-colors">FAQ</a>
        </div>

        <a href="#download" className="bg-primary/10 border border-primary text-primary hover:bg-primary hover:text-white px-4 py-2 rounded-md font-bold transition-all box-shadow-glow">
          DOWNLOAD
        </a>
      </div>
    </motion.nav>
  );
}
