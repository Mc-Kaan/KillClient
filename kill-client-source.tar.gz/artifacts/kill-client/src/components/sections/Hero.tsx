import { motion } from "framer-motion";
import { useEffect, useState } from "react";

export function Hero() {
  const [mousePosition, setMousePosition] = useState({ x: 0, y: 0 });

  useEffect(() => {
    const handleMouseMove = (e: MouseEvent) => {
      setMousePosition({ x: e.clientX, y: e.clientY });
    };
    window.addEventListener("mousemove", handleMouseMove);
    return () => window.removeEventListener("mousemove", handleMouseMove);
  }, []);

  return (
    <section className="relative min-h-screen flex items-center justify-center overflow-hidden bg-background pt-16">
      {/* Background radial glow following mouse */}
      <div 
        className="pointer-events-none absolute inset-0 opacity-30 transition-opacity duration-300"
        style={{
          background: `radial-gradient(600px circle at ${mousePosition.x}px ${mousePosition.y}px, hsl(var(--primary) / 0.15), transparent 40%)`
        }}
      />
      
      {/* Background Particles Placeholder */}
      <div className="absolute inset-0 opacity-20 bg-[url('data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMjAiIGhlaWdodD0iMjAiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyI+PGNpcmNsZSBjeD0iMSIgY3k9IjEiIHI9IjEiIGZpbGw9IiNmZmZmZmYiLz48L3N2Zz4=')] [mask-image:linear-gradient(to_bottom,white,transparent)]" />

      <div className="container relative z-10 mx-auto px-4 text-center">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          className="max-w-4xl mx-auto"
        >
          <h1 className="text-6xl md:text-8xl lg:text-9xl font-heading font-bold text-white mb-6 uppercase tracking-tighter text-shadow-glow animate-glitch">
            KILL<span className="text-primary">CLIENT</span>
          </h1>
          <p className="text-xl md:text-2xl text-muted-foreground mb-10 font-medium max-w-2xl mx-auto">
            Dominate every server with the next-generation Minecraft experience. Built for those who obliterate the competition.
          </p>
          
          <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
            <a 
              href="#download"
              className="w-full sm:w-auto px-8 py-4 bg-primary text-white font-bold rounded-md uppercase tracking-wider box-shadow-glow hover:scale-105 transition-transform"
            >
              Download Now
            </a>
            <a 
              href="#features"
              className="w-full sm:w-auto px-8 py-4 bg-white/5 border border-white/10 text-white font-bold rounded-md uppercase tracking-wider hover:bg-white/10 transition-all backdrop-blur-sm"
            >
              View Features
            </a>
          </div>
        </motion.div>
      </div>
    </section>
  );
}
