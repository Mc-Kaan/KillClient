import { motion, AnimatePresence } from "framer-motion";
import { useState } from "react";
import { Plus, Minus } from "lucide-react";

const faqs = [
  {
    q: "Is Kill Client safe to use on servers like Hypixel or Minemen?",
    a: "Kill Client is engineered with server-side anti-cheat in mind. Our modules are carefully tuned to stay within the detection thresholds of Watchdog, Badlion AC, and other major anti-cheat systems. We continuously update to maintain compatibility.",
  },
  {
    q: "What Minecraft versions are supported?",
    a: "Kill Client supports Minecraft versions 1.8.9 through 1.21. Our 1.8.9 build is the most optimized for PvP with legacy combat mechanics. We push updates within 48 hours of new Minecraft releases.",
  },
  {
    q: "How much does Kill Client cost?",
    a: "Kill Client is completely free. Always has been, always will be. We are funded by our Discord community and optional cosmetic purchases. No premium tier, no paywalled features.",
  },
  {
    q: "How do I install Kill Client?",
    a: "Download the installer, run it, and it auto-detects your Minecraft installation. The entire process takes under 2 minutes. No manual file editing, no .jar swapping. Full video tutorial available in our Discord.",
  },
  {
    q: "How does the FPS boost work?",
    a: "Kill Client replaces Minecraft's default rendering pipeline with our proprietary OptimizedGL engine. We batch draw calls, aggressively cull unseen chunks, and eliminate redundant CPU-GPU sync operations. Most users see a 3-6x FPS increase.",
  },
  {
    q: "Can I use Kill Client on cracked/offline servers?",
    a: "Yes. Kill Client works on both premium (online mode) and cracked (offline mode) servers. Your authentication mode is fully preserved.",
  },
  {
    q: "Does it support Forge mods or resource packs?",
    a: "Kill Client is compatible with all OptiFine resource packs and most lightweight Forge mods. We include a built-in resource pack manager and compatibility layer for common mod types.",
  },
  {
    q: "What if I get banned while using Kill Client?",
    a: "If you follow our recommended settings and use only the modules listed as 'server-safe' in our documentation, ban risk is minimal. We offer a dedicated support channel in Discord where our team reviews your config before you play competitively.",
  },
];

function FAQItem({ item, index }: { item: typeof faqs[0]; index: number }) {
  const [open, setOpen] = useState(false);

  return (
    <motion.div
      initial={{ opacity: 0, y: 16 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true }}
      transition={{ delay: index * 0.06 }}
      className="border-b border-white/8 last:border-0"
      data-testid={`faq-item-${index}`}
    >
      <button
        onClick={() => setOpen(!open)}
        className="w-full flex items-center justify-between py-5 text-left group"
        data-testid={`faq-toggle-${index}`}
      >
        <span className="font-heading font-bold text-white group-hover:text-primary transition-colors duration-200 uppercase tracking-wide text-sm md:text-base pr-4">
          {item.q}
        </span>
        <div
          className="flex-shrink-0 w-8 h-8 rounded-full flex items-center justify-center transition-all duration-300"
          style={{
            background: open ? "hsl(0 100% 55% / 0.15)" : "hsl(0 0% 12%)",
            border: `1px solid ${open ? "hsl(0 100% 55% / 0.4)" : "hsl(0 0% 20%)"}`,
          }}
        >
          {open ? (
            <Minus className="w-4 h-4 text-primary" />
          ) : (
            <Plus className="w-4 h-4 text-muted-foreground group-hover:text-primary transition-colors" />
          )}
        </div>
      </button>

      <AnimatePresence>
        {open && (
          <motion.div
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: "auto", opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            transition={{ duration: 0.3, ease: "easeInOut" }}
            className="overflow-hidden"
          >
            <p className="text-muted-foreground text-sm leading-relaxed pb-5 pr-12">
              {item.a}
            </p>
          </motion.div>
        )}
      </AnimatePresence>
    </motion.div>
  );
}

export function FAQ() {
  return (
    <section id="faq" className="py-24 bg-background relative overflow-hidden">
      <div className="container mx-auto px-4">
        <div className="max-w-3xl mx-auto">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-center mb-16"
          >
            <p className="text-primary font-heading font-bold tracking-widest uppercase text-sm mb-3">Support</p>
            <h2 className="text-4xl md:text-5xl font-heading font-bold uppercase text-white mb-4">
              Got <span className="text-primary">Questions?</span>
            </h2>
            <p className="text-muted-foreground text-lg">
              Everything you need to know before you destroy your first server.
            </p>
          </motion.div>

          <div
            className="rounded-xl p-8"
            style={{
              background: "hsl(0 0% 6%)",
              border: "1px solid hsl(0 0% 12%)",
            }}
          >
            {faqs.map((item, i) => (
              <FAQItem key={i} item={item} index={i} />
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
