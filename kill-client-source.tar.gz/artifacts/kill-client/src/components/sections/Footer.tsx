import { motion } from "framer-motion";
import { SiDiscord, SiX, SiGithub, SiYoutube } from "react-icons/si";

const navLinks = [
  { label: "Features", href: "#features" },
  { label: "Screenshots", href: "#screenshots" },
  { label: "Stats", href: "#stats" },
  { label: "Testimonials", href: "#testimonials" },
  { label: "Download", href: "#download" },
  { label: "FAQ", href: "#faq" },
];

const socials = [
  { icon: SiDiscord, label: "Discord", href: "#" },
  { icon: SiX, label: "X / Twitter", href: "#" },
  { icon: SiGithub, label: "GitHub", href: "#" },
  { icon: SiYoutube, label: "YouTube", href: "#" },
];

export function Footer() {
  return (
    <footer className="relative bg-background border-t border-white/[0.06] overflow-hidden">
      <div
        className="absolute top-0 left-0 right-0 h-px"
        style={{
          background: "linear-gradient(90deg, transparent, hsl(0 100% 55% / 0.4), hsl(270 100% 50% / 0.4), transparent)",
        }}
      />
      <div
        className="absolute inset-0 opacity-[0.015]"
        style={{
          backgroundImage: `repeating-linear-gradient(
            90deg, transparent, transparent 63px,
            rgba(255,255,255,0.4) 63px, rgba(255,255,255,0.4) 64px
          )`,
        }}
      />

      <div className="container mx-auto px-4 py-16 relative z-10">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-10 mb-12">
          <div>
            <div className="flex items-center gap-2 mb-4">
              <svg width="32" height="32" viewBox="0 0 32 32" fill="none" xmlns="http://www.w3.org/2000/svg"
                className="drop-shadow-[0_0_8px_rgba(255,0,0,0.5)]">
                <path d="M6 4H12V12L20 4H28L18 16L28 28H20L12 18V28H6V4Z" fill="hsl(0, 100%, 55%)" />
              </svg>
              <span className="font-heading font-bold text-xl tracking-wider text-white">
                KILL<span className="text-primary">CLIENT</span>
              </span>
            </div>
            <p className="text-muted-foreground text-sm leading-relaxed max-w-xs">
              The next-generation Minecraft PvP client. Built for dominance. Engineered for winners.
            </p>
          </div>

          <div>
            <div className="font-heading font-bold text-white uppercase tracking-widest text-xs mb-4">Navigation</div>
            <ul className="space-y-2">
              {navLinks.map((link) => (
                <li key={link.label}>
                  <a
                    href={link.href}
                    className="text-muted-foreground hover:text-primary transition-colors text-sm"
                    data-testid={`footer-link-${link.label.toLowerCase()}`}
                  >
                    {link.label}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          <div>
            <div className="font-heading font-bold text-white uppercase tracking-widest text-xs mb-4">Community</div>
            <div className="flex gap-3 mb-6">
              {socials.map((s) => (
                <motion.a
                  key={s.label}
                  href={s.href}
                  whileHover={{ scale: 1.15, y: -2 }}
                  className="w-10 h-10 rounded-lg flex items-center justify-center text-muted-foreground hover:text-white transition-colors duration-200"
                  style={{
                    background: "hsl(0 0% 10%)",
                    border: "1px solid hsl(0 0% 16%)",
                  }}
                  aria-label={s.label}
                  data-testid={`footer-social-${s.label.toLowerCase()}`}
                >
                  <s.icon className="w-4 h-4" />
                </motion.a>
              ))}
            </div>
            <div
              className="inline-flex items-center gap-2 px-3 py-2 rounded-lg text-xs"
              style={{
                background: "hsl(0 0% 8%)",
                border: "1px solid hsl(0 0% 14%)",
                color: "hsl(0 0% 55%)",
              }}
            >
              <span
                className="w-2 h-2 rounded-full"
                style={{ background: "#22ff66", boxShadow: "0 0 6px #22ff66" }}
              />
              50,247 players online now
            </div>
          </div>
        </div>

        <div
          className="flex flex-col sm:flex-row items-center justify-between pt-8 gap-4"
          style={{ borderTop: "1px solid hsl(0 0% 10%)" }}
        >
          <p className="text-muted-foreground text-xs">
            2025 Kill Client. All rights reserved. Not affiliated with Mojang Studios.
          </p>
          <div className="flex items-center gap-4 text-xs text-muted-foreground">
            <a href="#" className="hover:text-primary transition-colors">Terms</a>
            <a href="#" className="hover:text-primary transition-colors">Privacy</a>
            <a href="#" className="hover:text-primary transition-colors">Cookies</a>
          </div>
        </div>
      </div>
    </footer>
  );
}
